<?php

$aliases['isp'] = array (
  'remote-host' => 'hydrogen.server.org',
  'remote-user' => 'www-admin',
);

$aliases['nitrogen'] = array (
  'remote-host' => 'nitrogen.server.org',
  'remote-user' => 'admin',
);
