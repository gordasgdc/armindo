<?php

namespace DMore\ChromeDriver;

use Behat\Mink\Exception\DriverException;

class NoSuchFrameException extends DriverException
{

}