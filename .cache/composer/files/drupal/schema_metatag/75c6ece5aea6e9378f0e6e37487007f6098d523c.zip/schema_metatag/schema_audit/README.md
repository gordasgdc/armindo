# Schema.org Audit

A tool to retrieve Schema.org definitions and compare them to what is in the Drupal module. 
