<?php

namespace Drupal\simple_oauth\Normalizer;

use Symfony\Component\Serializer\Normalizer\NormalizerInterface;

interface TokenEntityNormalizerInterface extends NormalizerInterface {}
