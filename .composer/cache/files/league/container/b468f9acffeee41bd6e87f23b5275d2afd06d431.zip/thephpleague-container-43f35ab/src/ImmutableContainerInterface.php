<?php

namespace League\Container;

use Interop\Container\ContainerInterface as InteropContainerInterface;

interface ImmutableContainerInterface extends InteropContainerInterface
{

}
