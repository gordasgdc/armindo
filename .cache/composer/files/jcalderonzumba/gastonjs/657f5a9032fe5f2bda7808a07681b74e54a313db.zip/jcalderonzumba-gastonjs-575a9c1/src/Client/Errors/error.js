/**
 *  Poltergeist base error class
 */
Poltergeist.Error = (function () {
  function Error() {
  }

  return Error;

})();
