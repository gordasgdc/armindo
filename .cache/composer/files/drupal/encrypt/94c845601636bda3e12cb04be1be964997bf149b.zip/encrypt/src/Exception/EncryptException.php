<?php

namespace Drupal\encrypt\Exception;

/**
 * Class EncryptException.
 */
class EncryptException extends \Exception {}
