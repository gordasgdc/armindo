These hooks are used by Acquia Cloud as part of Lightning's CI. They are not
executed on sites that use Lightning. For more information, see 
[Acquia's CLoud Hook Documentation](https://docs.acquia.com/acquia-cloud/api/cloud-hooks).