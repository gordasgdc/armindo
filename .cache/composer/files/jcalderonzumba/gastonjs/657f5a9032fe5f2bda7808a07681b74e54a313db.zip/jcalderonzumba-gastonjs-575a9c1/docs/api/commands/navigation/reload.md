reload
========
This command allows you to reload the page you are currently in, to reload send:
```json
{
  "name":"reload",
  "args":[]
}
```
Response should be:
```json
{
  "response": true
}
```
