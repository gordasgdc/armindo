# OpenAPI reDoc Module

This module provides a reDoc documentation ui for Drupal Core and JsonApi REST
Resources.

[Learn more about reDoc](https://github.com/Rebilly/ReDoc).
