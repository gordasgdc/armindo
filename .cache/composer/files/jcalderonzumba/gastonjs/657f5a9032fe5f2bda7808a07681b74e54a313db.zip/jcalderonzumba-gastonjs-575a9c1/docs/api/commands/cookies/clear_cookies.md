clear_cookies
=========
Command to clear all the cookies set in the browser
##Request
```json
{
    "name": "clear_cookies",
    "args": []
}
```
##Response
```json
{
    "response": true
}
```
