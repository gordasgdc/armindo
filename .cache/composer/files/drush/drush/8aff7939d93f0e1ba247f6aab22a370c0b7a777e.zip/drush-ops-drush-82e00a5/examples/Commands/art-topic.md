I have discovered a truly marvelous proof that it is impossible to 
separate a piece of art into two cubes, or four pieces of art into two
fourth of a piece of art, or in general, any artwork larger than the 
second into two like artistic expressions. 

This text file is too narrow to contain it.
