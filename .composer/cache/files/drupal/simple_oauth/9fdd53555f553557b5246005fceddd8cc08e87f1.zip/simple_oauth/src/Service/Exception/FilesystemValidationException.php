<?php

namespace Drupal\simple_oauth\Service\Exception;

use Exception;

/**
 * @internal
 */
class FilesystemValidationException extends Exception {}
