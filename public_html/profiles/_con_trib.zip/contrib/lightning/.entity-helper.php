<?php

namespace Drupal\entity\Entity;

interface RevisionableEntityBundleInterface {}
