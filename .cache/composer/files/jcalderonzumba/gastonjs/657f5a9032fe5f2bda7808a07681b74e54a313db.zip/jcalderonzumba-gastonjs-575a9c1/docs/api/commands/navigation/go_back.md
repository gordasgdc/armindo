go_back
========
This command allows you (if possible) to go back, loading the previous page in your browser history.

```json
{
  "name":"go_back",
  "args":[]
}
```
If possible to go back then response should be:
```json
{
  "response": true
}
```
