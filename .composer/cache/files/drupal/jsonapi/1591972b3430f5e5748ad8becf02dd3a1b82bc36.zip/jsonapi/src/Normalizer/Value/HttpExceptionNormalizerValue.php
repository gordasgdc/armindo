<?php

namespace Drupal\jsonapi\Normalizer\Value;

/**
 * Helps normalize exceptions in compliance with the JSON API spec.
 *
 * @internal
 */
class HttpExceptionNormalizerValue extends FieldNormalizerValue {}
