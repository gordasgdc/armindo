<?php 
require('fonts.php');
print gavias_buildpro_links_typography_font($json);
require('dynamic_style.php');