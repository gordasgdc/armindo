<?php

namespace Drupal\jsonapi\Normalizer;

/**
 * Converts the Drupal content entity object to a JSON API array structure.
 *
 * @internal
 */
class ContentEntityNormalizer extends EntityNormalizer {}
