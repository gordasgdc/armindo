go_forward
========
This command allows you (if possible) to go forward, loading the next page in your browser history.
```json
{
  "name":"go_forward",
  "args":[]
}
```
If possible to go forward then response should be:
```json
{
  "response": true
}
```
