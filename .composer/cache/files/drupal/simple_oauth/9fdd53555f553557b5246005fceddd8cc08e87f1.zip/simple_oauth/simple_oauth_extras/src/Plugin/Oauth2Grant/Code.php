<?php

namespace Drupal\simple_oauth_extras\Plugin\Oauth2Grant;

/**
 * @Oauth2Grant(
 *   id = "code",
 *   label = @Translation("Code")
 * )
 */
class Code extends AuthorizationCode {}
