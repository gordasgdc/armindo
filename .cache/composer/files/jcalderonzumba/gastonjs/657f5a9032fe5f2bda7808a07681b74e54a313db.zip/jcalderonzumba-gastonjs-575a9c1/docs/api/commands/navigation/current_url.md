current-url
===================

To get the current url in the browser, send:
```json
{
  "name":"current_url",
  "args":[]
}
```
Response should be:
```json
{
  "response":"http://gastonjs.readthedocs.org/en/latest/"
}
```
